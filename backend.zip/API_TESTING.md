# Ekuinox Backend API Testing Guide

This document provides comprehensive payload examples and testing instructions for all API endpoints.

## Base Configuration

**Base URL**: `http://localhost:5000/api`
**Content-Type**: `application/json`
**Authentication**: Bearer token in Authorization header

## 🔐 Authentication Endpoints

### 1. Register User
**POST** `/auth/register`

```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "password": "Password123!",
  "confirmPassword": "Password123!",
  "phone": "+1234567890",
  "role": "user"
}
```

**Response:**
```json
{
  "success": true,
  "token": "jwt-token-here",
  "data": {
    "user": {
      "_id": "user-id",
      "name": "John Doe",
      "email": "john.doe@example.com",
      "role": "user",
      "isActive": true
    }
  }
}
```

### 2. Login User
**POST** `/auth/login`

```json
{
  "email": "john.doe@example.com",
  "password": "Password123!"
}
```

### 3. Get Current User Profile
**GET** `/auth/me`
*Requires Authentication*

**Headers:**
```
Authorization: Bearer your-jwt-token
```

### 4. Update User Details
**PUT** `/auth/updatedetails`
*Requires Authentication*

```json
{
  "name": "John Updated",
  "email": "john.updated@example.com",
  "phone": "+1987654321"
}
```

### 5. Update Password
**PUT** `/auth/updatepassword`
*Requires Authentication*

```json
{
  "currentPassword": "Password123!",
  "newPassword": "NewPassword456!",
  "confirmPassword": "NewPassword456!"
}
```

## 📦 Product Endpoints

### 6. Get Latest Product
**GET** `/products/latest`

**Response:**
```json
{
  "success": true,
  "data": {
    "_id": "product-id",
    "name": "Latest Product Name",
    "description": "Product description",
    "price": "299.99",
    "sku": "LATEST-001",
    "stock": 25,
    "category": "Watch",
    "status": "Active",
    "createdAt": "2025-11-01T10:00:00.000Z",
    "updatedAt": "2025-11-01T10:00:00.000Z"
  }
}
```

### 7. Create Product
**POST** `/products`
*Admin Only*

```json
{
  "name": "Premium Smart Watch Series X",
  "description": "Advanced smart watch with health monitoring, GPS tracking, and premium titanium case. Features include heart rate monitoring, sleep tracking, and 7-day battery life.",
  "price": "499.99",
  "sku": "SW-PREM-001",
  "stock": 100,
  "category": "Watch",
  "status": "Active",
  "sizes": ["40mm", "44mm", "48mm"],
  "editions": ["Standard", "Premium", "Limited"],
  "colors": [
    {
      "id": "black",
      "alt": "Midnight Black",
      "thumb": "https://example.com/thumb-black.jpg",
      "gallery": [
        "https://example.com/gallery-black-1.jpg",
        "https://example.com/gallery-black-2.jpg"
      ]
    },
    {
      "id": "silver", 
      "alt": "Platinum Silver",
      "thumb": "https://example.com/thumb-silver.jpg",
      "gallery": [
        "https://example.com/gallery-silver-1.jpg"
      ]
    }
  ],
  "stats": [
    {
      "label": "Battery Life",
      "value": "7 days"
    },
    {
      "label": "Water Resistance", 
      "value": "50m"
    },
    {
      "label": "Display",
      "value": "1.8\" AMOLED"
    }
  ],
  "subItems": [
    {
      "name": "Premium Band",
      "price": "79.99",
      "description": "Genuine leather band with quick-release clasp",
      "image": "https://example.com/band.jpg"
    },
    {
      "name": "Wireless Charger",
      "price": "49.99", 
      "description": "Fast wireless charging dock",
      "image": "https://example.com/charger.jpg"
    }
  ],
  "videoTitle": "Product Overview Video",
  "videoUrl": "https://youtube.com/watch?v=example",
  "images": [
    {
      "url": "https://example.com/main-image.jpg",
      "alt": "Premium Smart Watch Main View",
      "isMain": true
    },
    {
      "url": "https://example.com/side-view.jpg", 
      "alt": "Premium Smart Watch Side View",
      "isMain": false
    }
  ],
  "features": [
    {
      "title": "Health Monitoring",
      "description": "24/7 heart rate and sleep tracking",
      "icon": "heart",
      "image": "https://example.com/health-monitoring.jpg"
    },
    {
      "title": "GPS Tracking",
      "description": "Built-in GPS for accurate location tracking",
      "icon": "map-pin",
      "image": "https://example.com/gps-tracking.jpg"
    }
  ],
  "relatedProducts": ["507f1f77bcf86cd799439011", "507f1f77bcf86cd799439012"],
  "specifications": {
    "Display": "1.8\" AMOLED, 390x390 pixels",
    "Processor": "Dual-core 1.8GHz",
    "Storage": "32GB",
    "Connectivity": "WiFi, Bluetooth 5.0, GPS",
    "Sensors": "Heart Rate, Accelerometer, Gyroscope",
    "Battery": "300mAh, 7-day life",
    "Water Resistance": "5ATM",
    "Weight": "45g",
    "Dimensions": "44mm x 38mm x 11mm"
  },
  "tags": ["smartwatch", "fitness", "premium", "titanium", "health"],
  "seoTitle": "Premium Smart Watch Series X - Advanced Health & Fitness Tracking",
  "seoDescription": "Discover the Premium Smart Watch Series X with advanced health monitoring, GPS tracking, and premium design. Shop now for the best smartwatch experience.",
  "seoKeywords": ["smart watch", "fitness tracker", "health monitoring", "GPS watch"],
## 🛒 Cart Endpoints

### 8. Get User Cart
**GET** `/cart`
*Requires Authentication*

**Headers:**
```
Authorization: Bearer your-jwt-token
```

**Response:**
```json
{
  "success": true,
  "data": {
    "_id": "cart-id",
    "user": "user-id",
    "items": [
      {
        "_id": "item-id",
        "product": {
          "_id": "product-id",
          "name": "Premium Smart Watch",
          "price": "499.99",
          "sku": "SW-PREM-001",
          "images": [{"url": "https://example.com/watch.jpg"}],
          "category": "Watch"
        },
        "quantity": 2,
        "price": "499.99",
        "addedAt": "2025-11-01T12:00:00.000Z"
      }
    ],
    "total": 999.98,
    "itemCount": 2,
    "status": "active",
    "createdAt": "2025-11-01T10:00:00.000Z",
    "updatedAt": "2025-11-01T12:00:00.000Z"
  }
}
```

### 9. Get Cart Summary
**GET** `/cart/summary`
*Requires Authentication*

**Response:**
```json
{
  "success": true,
  "data": {
    "itemCount": 3,
    "total": 1499.97
  }
}
```

### 10. Add Item to Cart
**POST** `/cart/items`
*Requires Authentication*

```json
{
  "productId": "507f1f77bcf86cd799439011",
  "quantity": 1
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "_id": "cart-id",
    "user": "user-id",
    "items": [
      {
        "_id": "item-id",
        "product": {
          "_id": "507f1f77bcf86cd799439011",
          "name": "Premium Smart Watch",
          "price": "499.99",
          "sku": "SW-PREM-001",
          "images": [{"url": "https://example.com/watch.jpg"}],
          "category": "Watch"
        },
        "quantity": 1,
        "price": "499.99",
        "addedAt": "2025-11-01T12:00:00.000Z"
      }
    ],
    "total": 499.99,
    "itemCount": 1,
    "status": "active"
  }
}
```

### 11. Update Cart Item Quantity
**PUT** `/cart/items/:itemId`
*Requires Authentication*

```json
{
  "quantity": 3
}
```

### 12. Remove Item from Cart
**DELETE** `/cart/items/:itemId`
*Requires Authentication*

### 13. Clear Cart
**DELETE** `/cart`
*Requires Authentication*

**Response:**
```json
{
  "success": true,
  "message": "Cart cleared successfully",
  "data": {
    "items": [],
    "total": 0,
    "itemCount": 0
  }
}
```

### 14. Checkout Cart
**POST** `/cart/checkout`
*Requires Authentication*

**Response:**
```json
{
  "success": true,
  "message": "Checkout completed successfully",
  "data": {
    "orderId": "cart-id",
    "total": 999.98,
    "itemCount": 2,
    "items": [
      {
        "_id": "item-id",
        "product": {
          "_id": "product-id",
          "name": "Premium Smart Watch",
          "price": "499.99"
        },
        "quantity": 2,
        "price": "499.99"
      }
    ]
  }
}
```
**GET** `/products`

**Query Parameters:**
```
?page=1&limit=10&search=shirt&category=Clothing&sort=-createdAt&status=active&featured=true
```

### 3. Get Single Product
**GET** `/products/:id`

### 4. Update Product
**PUT** `/products/:id`
*Admin Only*

```json
{
  "name": "Updated Premium T-Shirt",
  "price": 34.99,
  "quantity": 150,
  "status": "active"
}
```

### 5. Delete Product
**DELETE** `/products/:id`
*Admin Only*

## 👥 User Management (Admin Only)

### 1. Get All Users
**GET** `/users`
*Admin Only*

**Query Parameters:**
```
?page=1&limit=10&role=user&status=active&search=john
```

### 2. Create User
**POST** `/users`
*Admin Only*

```json
{
  "name": "Jane Admin",
  "email": "jane.admin@example.com",
  "password": "AdminPass123!",
  "role": "admin",
  "phone": "+1122334455"
}
```

### 3. Update User
**PUT** `/users/:id`
*Admin Only*

```json
{
  "name": "Jane Updated",
  "role": "user",
  "isActive": true
}
```

### 4. Toggle User Status
**PATCH** `/users/:id/status`
*Admin Only*

```json
{
  "isActive": false
}
```

## 🌍 Location Endpoints

### 1. Create Country
**POST** `/countries`
*Admin Only*

```json
{
  "name": "United States",
  "code": "US",
  "currency": "USD",
  "timezone": "America/New_York"
}
```

### 2. Get All Countries
**GET** `/countries`

### 3. Create City
**POST** `/cities`
*Admin Only*

```json
{
  "name": "New York",
  "country": "country-id-here",
  "state": "New York",
  "zipCode": "10001"
}
```

### 4. Get Cities by Country
**GET** `/cities/country/:countryId`

## 🛡️ Admin Endpoints

### 1. Initialize Admin (One-time setup)
**POST** `/admin/init`

```json
{
  "email": "admin@ekuinox.com",
  "password": "SuperAdmin123!",
  "name": "System Administrator"
}
```

### 2. Get Dashboard Statistics
**GET** `/admin/dashboard`
*Admin Only*

### 3. Get System Information
**GET** `/admin/system`
*Admin Only*

## 🧪 Testing Commands

### Using cURL

#### 1. Register User
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "Test123!",
    "confirmPassword": "Test123!"
  }'
```

#### 2. Login User
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test123!"
  }'
```

#### 3. Get Products (No Auth Required)
```bash
curl -X GET "http://localhost:5000/api/products?page=1&limit=5"
```

#### 4. Create Product (Admin Required)
```bash
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "name": "Test Product",
    "description": "A test product",
    "category": "Electronics",
    "price": 99.99,
    "quantity": 50
  }'
```

## ⚡ Quick Test Script

Save this as `test-api.sh` and run `chmod +x test-api.sh && ./test-api.sh`:

```bash
#!/bin/bash

BASE_URL="http://localhost:5000/api"

echo "🔍 Testing Ekuinox Backend API..."

# Test health endpoint
echo -e "\n1️⃣ Testing Health Endpoint..."
curl -s "$BASE_URL/../health" | jq '.'

# Test user registration
echo -e "\n2️⃣ Testing User Registration..."
REGISTER_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "Test123!",
    "confirmPassword": "Test123!"
  }')
echo $REGISTER_RESPONSE | jq '.'

# Extract token
TOKEN=$(echo $REGISTER_RESPONSE | jq -r '.token // empty')

if [ ! -z "$TOKEN" ]; then
  echo -e "\n3️⃣ Testing Protected Route (Get Profile)..."
  curl -s -X GET "$BASE_URL/auth/me" \
    -H "Authorization: Bearer $TOKEN" | jq '.'
    
  echo -e "\n4️⃣ Testing Get Products..."
  curl -s -X GET "$BASE_URL/products" | jq '.'
else
  echo "❌ Registration failed, skipping authenticated tests"
fi

echo -e "\n✅ API Testing Complete!"
```

## 📝 Response Format

### Success Response
```json
{
  "success": true,
  "data": { /* response data */ },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error message",
  "errors": [
    {
      "field": "email",
      "message": "Email is required"
    }
  ]
}
```

### Paginated Response
```json
{
  "success": true,
  "count": 10,
  "total": 100,
  "pagination": {
    "currentPage": 1,
    "totalPages": 10,
    "hasNext": true,
    "hasPrev": false
  },
  "data": [ /* array of items */ ]
}
```

## 🚨 Common Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request (Validation Error)
- `401` - Unauthorized (No/Invalid Token)
- `403` - Forbidden (Insufficient Permissions)
- `404` - Not Found
- `409` - Conflict (Duplicate Resource)
- `500` - Internal Server Error

## 🔧 Environment Requirements

Make sure your `.env` file is configured:
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/ekuinox
JWT_SECRET=your-secret-key
JWT_EXPIRE=30d
FRONTEND_URL=http://localhost:3000
```